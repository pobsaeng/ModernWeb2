﻿Ext.define('iPartner.store.ApplicationSummary', {
    extend: 'Ext.data.Store',
    alias: 'store.application-service',

    fields: [
        {
            name: 'id',
            type: 'int'
        },
        'customerTitle',
		'customerFirstName',
		'customerLastName',
		'requestNo',
		'carRegistrationNo',
		'carProvinceRegistered',
		'carBrand',
		'carModel',
		'status'
    ],
    autoLoad: false,
    pageSize: 20,

    listeners: {
        beforeload: function (store, operation, eOpts) {
            var proxy = store.getProxy();
            proxy.setUrl(iPartner.getApplication().getGateway());
            proxy.setHeaders({
                'Authorization': 'key=' + iPartner.getApplication().getAuthorizeKey()
            });
            
            //console.log(operation);
            //console.log(operation._limit);

            var extraParams = proxy.getExtraParams();
            var request = Ext.decode(extraParams.request) || {};
            
            var serviceParams = Ext.decode(request.serviceParams) || [{}, {}];
            serviceParams[1].resultOffset = operation._start;
            serviceParams[1].resultSize = operation._limit;

            request.serviceParams = Ext.encode(serviceParams);
            extraParams = { request: Ext.encode(request) };
            proxy.setExtraParams(extraParams);
        }
    },

    proxy: {
        type: 'ajax',
        useDefaultXhrHeader: false,  // This should be set to false when making CORS (cross-domain) requests.
        actionMethods: {
            read: 'POST'
        },
        enablePaging: true,
        listeners: {
            exception: function (proxy, request, operation, eOpts) {
                var app = iPartner.getApplication();
                var exception = {code: 'IPART_503', message: 'Service Unavailable'}
                app.apiExceptionHandler(exception);
            }
        },
        reader: {
            type: 'json',
            rootProperty: 'applications',
            totalProperty: 'totalResult',
            transform: {
                fn: function (data) {
                    //console.log(data);
                    if (!data || Object.getOwnPropertyNames(data).length == 0) {
                        //console.log('empty response: ' + Ext.encode(data));
                        return [];
                    }
                    if (data.exception) {
                        //console.log('Response Exception: ' + data.exception);
                        iPartner.getApplication().apiExceptionHandler(Ext.decode(data.exception));
                        return [];
                    };

                    // do some manipulation of the raw data object
                    return Ext.decode(data.result);
                },
                scope: this
            }
        }
    }
});