﻿Ext.define('iPartner.store.Base', {
    extend: 'Ext.data.Store',
    autoload: false,
    listeners: {
        beforeload: function (store, operation, eOpts) {
            var proxy = store.getProxy();
            proxy.setUrl(iPartner.getApplication().getGateway());
            proxy.setHeaders({
                'Authorization': 'key=' + iPartner.getApplication().getAuthorizeKey()
            });
            proxy.setUseDefaultXhrHeader(false);
            proxy.setActionMethods({ read: 'POST' });
            proxy.setType('ajax');
        }
    }
});