﻿Ext.define('iPartner.store.Sitemap', {
    extend: 'Ext.data.TreeStore',
    alias: 'store.sitemap',
    storeId: 'sitemap',

    fields: [
        { name: 'text', type: 'string' },
        { name: 'leaf', type: 'bool' },
        { name: 'rootId', type: 'string' },
        { name: 'expandable', type: 'bool', defaultValue: false }
    ],
    autoLoad: true,
    //defaultRootProperty: 'root',
    //defaultRootId: 'home',
    defaultRootText: 'Home',
    proxy: {
        type: 'ajax',
        url: 'resources/sitemap.json',
        //rootProperty: 'root',
        reader: {
            type: 'json',
            //rootProperty: 'root',
            transform: {
                fn: function (data) {
                    //console.log(data);
                    return data;
                }
            }
        }
    }
});